﻿
#if 0
// 상속 관계에 있을 때, 부모 생성자가 만약 기본 생성자가 없을 경우
// 멤버 이니셜라이저를 사용하여 호출할 수 있다.
#include <iostream>
using namespace std;

struct Parent {
	Parent(int a) { cout << "Parent(" << a << ")\n"; }

	// 어떠한 클래스가 부모 클래스로 사용된다면 반드시 부모 클래스의
	// 소멸자는 가상으로 선언해야 합니다.
	virtual ~Parent() { cout << "~Parent()\n"; }
};

struct Child : public Parent {
	Child() : Parent(0) { cout << "Child()\n"; }
	~Child() { cout << "~Child()\n"; }
};

void main() {
	// Child c;
	Parent* p = new Child;
	delete p;
}
#endif



#if 0
class Rect {
	// ...
public:
	void draw() {	// void draw(Rect* const this);
		cout << "직사각형\n";
	}
};

class RoundRect : public Rect {
	// ...
public:
	// 함수 오버라이딩: 상속 관계에 있을 때, 자식이 부모의 함수를 재정의
	// 하는 것 -> 부모 함수의 시그니처와 완벽하게 동일해야 함
	void draw() {	// void draw(RoundRect* const this);
		Rect::draw();	// super.draw(); in Java
		cout << "둥근사각형\n";
	}
};

void main() {
	RoundRect r;// Rect r;
	r.draw();	// draw(r);
}

#endif

#if 0
// 정적 바인딩
// 동적 바인딩

class Animal
{
public:
	// 자식에게 공통의 기능이 있다면 반드시 그 기능은 부모가 제공해야 합니다.
	// LSP(리스코프의 치환 원칙)
	virtual void cry() {	// void cry(Animal* const);
		cout << "Animal::cry()\n";
	}
};

class Cat : public Animal
{
public:
	void cry() {	// void cry(Cat* const);
		cout << "Cat::cry()\n";
	}
};

void main() {
	Animal* p = new Cat;	// upcasting, 캐스팅 연산자를 생략할 수 있음
	p->cry();	// cry(p);
}

// 문법적 측면: 기능을 재사용
// 디자인 측면: 서로 다른 타입을 동종의 타입으로 처리하기 위해 사용

#endif

#if 0
// 인터페이스: 어떠한 클래스에게 특정 기능을 강제화하기 위해 사용되는
// 고도로 추상화된 클래스입니다.

// 추상 클래스: 순수 가상 함수를 하나 이상 포함하고 있다면 그 클래스는
// 추상 클래스라고 합니다.
// 추상 클래스의 특징은 객체를 생성할 수 없습니다.
class Clazz
{
public:
	// 순수 가상 함수: 가상 함수이나 몸체가 없는 함수를 의미
	// 순수 가상 함수를 사용하는 이유는 자식에게 특정 기능을 구현하도록
	// 강제화하도록 하기 위해 사용
	virtual void func() = 0;

	void foo() {}
};

// 추상 클래스를 생성하려면 자식 클래스가 추상 클래스를 상속하고 자식이
// 부모의 순수 가상 함수를 구현하면 됩니다. 
class Child : public Clazz
{
public:
	virtual void func() {}
};

void main() {
	Child c;	//Clazz c;
}
#endif


#if 0
// 함수 템플릿: 함수의 기계어 코드를 자동으로 생성하는 틀(template)

template<typename T> T Max(T a, T b) {
	return a > b ? a : b; 
}

void main() {
	//int n = Max(1, 2);		// 암시적 인스턴스 
	//double m = Max(1.2, 2.2);

	int n = Max<int>(i, 'A');	// 명시적 인스턴스
}
#endif

#if 0
template<typename T> class Stack
{
	T* arr;
	int size;
public:
	void push(T data);
};

void main() {
	// Stack s;	// error, 타입이 아니라 틀 -> 암시적 인스턴스 불가능
	Stack<int> s;	// 명시적 인스터스로만 사용 가능
					// "Stack<int>"가 타입
}

template<typename T> void Stack<T>::push(T data) {}
#endif

#if 0
// 스마트 포인터: 객체가 임의의 포인터 역할을 하는 것
// 스마트 포인터는 진짜 포인터가 아니라 객체이므로 사용자가 객체의 생성/복사/대입
// 소멸의 과정을 제어할 수 있음
// 예) 소멸자를 사용한 자동 삭제

// 스마트 포인터는 ->, * 연산자를 오버로딩해야 함.

// 현재 스마트 포인터의 복사 정책을 참조 계수 기반으로 변경해 보세요 :D
template<typename T> class Sptr
{
	T* p;
	int* ref;
public:
	Sptr(T* ptr) : p(ptr), ref(new int(1)) {}

	// 참조 계수 방식의 복사 생성자
	Sptr(const Sptr& other) : p(other.p), ref(other.ref) {	// 1. 얕은 복사 후
		++(*ref);	// 2. 참조 계수만 증분
	}

	// 참조 계수 방식의 소멸자
	~Sptr() {
		if (--(*ref) == 0) {
			delete ref;
			delete p;
		}
	}

	T* operator->() { return p; }
	T& operator*() { return *p; }
};

void main() {
	//Sptr<int> p1 = new int;
	//*p1 = 0;
	//cout << *p1 << "\n";

	int* p1 = new int;
	int* p2 = p1;	// 포인터 앨리어싱

	Sptr<int> p3 = new int;
	Sptr<int> p4 = p3;	// Sptr<int> p4(p3);
	getchar();
}
#endif


// 이미 참조 계수 기반의 스마트 포인터는 표준(STL)에서 제공합니다.
#include <iostream>
#include <memory>	// 이 안에 참조 계수 기반의 스마트 포인터가 있습니다.
using namespace std;

void main() {
	shared_ptr<int> p1(new int);	// explict 사용
	*p1 = 0;
	cout << *p1 << "\n";

	shared_ptr<int> p2(p1);
	*p2 = 20;
	cout << *p1 << "\n";
}