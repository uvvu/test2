
#if 0
// Ŭ������ ����� ����
#include <iostream>
using namespace std;

// Stack.h -----------------------------
class Stack
{
	static int sint; //extren int sint;
	int* arr;
	int  size;

public:
	Stack();
	void push(int data); 
};
//--------------------------------------

//main.cpp -----------------------------
void main() {
	Stack s;

}
// --------------------------------------

// Stack.cpp ----------------------------
//#include "Stack.h"

int Stack::sint = 0;
Stack::Stack() { cout << "Stack()\n";  }
void Stack::push(int data) {}
// --------------------------------------

#endif

// Ŭ������ ����� ����
#include <iostream>
using namespace std;

template<typename T>class Stack
{
	static int sint; 
	T* arr;
	int  size;

public:
	Stack();
	void push(T data);
};


void main() {
	Stack<int> s;
}

template<typename T> int Stack<T>::sint = 0;

template<typename T>Stack<T>::Stack() { cout << "Stack()\n"; }

template<typename T> void Stack<T>::push(T data) {}

