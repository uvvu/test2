// ģ�� �̾߱�

#include <iostream>
using namespace std;

class Int32
{
	int var = 0;
public:
	int get_var() const { return var; }

	friend void print_int32(const Int32& i);
};

void print_int32(const Int32& i) {
	//cout << i.var << "\n";
	//cout << i.get_var() << "\n";
	cout << i.var << "\n";
}

void main() {
	Int32 i;
	print_int32(i);
}