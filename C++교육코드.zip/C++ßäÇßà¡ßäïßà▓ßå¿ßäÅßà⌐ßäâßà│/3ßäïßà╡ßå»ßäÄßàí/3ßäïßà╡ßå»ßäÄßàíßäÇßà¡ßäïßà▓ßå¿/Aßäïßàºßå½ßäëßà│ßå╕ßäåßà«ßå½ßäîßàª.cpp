
// ��������: ������ Ŭ������ ������ ������ 
#include <string.h>
#include <iostream>
using namespace std;

class String {
	char* str;
	int len;
public:
	int length() const { return len; }

	char& operator[](int i) { return str[i]; }
	char operator[](int i) const { return str[i]; }

	String(const char* c) {
		len = strlen(c);
		str = new char[len + 1];
		strcpy(str, c);  //  ^--- ASCII NULL
	}

	String(const String& o) : len(o.len) {
		str = new char[len + 1];
		strcpy(str, o.str);
	}
	~String() { delete[] str; }

	friend ostream& operator<<(ostream& cout, const String& s);
	
	String operator+(const String& other) {
		char* tmp = new char[len + other.len + 1];
		strcpy(tmp, str);
		strcat(tmp, other.str);

		String result(tmp);
		delete[] tmp;
		return result;
	}

	void operator+=(const char* s) {
		char* temp = new char[len + strlen(s) + 1];
		sprintf(temp, "%s%s", str, s);
		delete[] str;
		str = temp;
		cout << str << "\n";
	}

	bool operator==(const String& o) {
		return (strcmp(str, o.str) == 0);
	}
	
	String operator+(const char* s) {
		char* temp = new char[len + strlen(s) + 1];
		sprintf(temp, "%s%s", str, s);

		String result(temp);
		delete[] temp;
		return result;
	}
};
	
ostream& operator<<(ostream& cout, const String& s) {
	cout << s.str;
	return cout;
}


void main() {
	String hello = "hello";	// String hello("hello");
	cout << hello << "\n";
	
	String world = "world";

	String helloworld = hello + world; // hello.operator+
	cout << helloworld << "\n";
	
	for (int i = 0; i < helloworld.length(); i++)
		cout << helloworld[i] << "\n";

	hello += "world";
	if (hello == helloworld) // hello.operator==(helloworld);
		cout << "same\n";
	else
		cout << "not same\n";


	String str = world + "!!!!!!";
	cout << str << "\n";	// world!!!!!
}