import pandas as pd
import matplotlib.pyplot as mpl

class pandasInfo:
    def __init__(self):
        self.df = pd.DataFrame()
        self.index = 0
        
    def input_info(self):
        name = str(input("이름:"))
        kor = int(input("국어:"))
        eng = int(input("영어:"))
        math = int(input("수학:"))
        
        self.df[name] = [kor, eng, math, (kor + eng + math), ((kor + eng + math)/3) ]
        self.df.index = ["국어", "영어", "수학 ", "총점", "평균"]

    def print_info(self):
        x = self.df.T
        print("=======================================================")
        print(x.ix[:])
        print("======================================================")
        print("과목별 평균", self.df.iloc[0].mean(),self.df.iloc[1].mean(),self.df.iloc[2].mean())
    
    def stastic_info(self):
        print("=======================================================")
        print("과목별 최고 점수")
        print("국어  :",self.df.iloc[0].max())
        print("영어 :",self.df.iloc[1].max())
        print("수학 :",self.df.iloc[2].max())
        print("국어 점수 Total :",self.df.iloc[0].sum()  )
        print("영어 점수 Total :",self.df.iloc[1].sum()  )
        print("수학 점수 Total :",self.df.iloc[2].sum()  )
        print("======================================================")
        
        t = [0,1,2]
        tLable = ["국어평균", "영어평균", "수학평균"]

        x = (self.df.iloc[0].mean()) 
        y = (self.df.iloc[1].mean()) 
        z = (self.df.iloc[2].mean()) 
        y_val = (x,y,z) 
        mpl.xticks(t, tLable)
        mpl.rc('font', family='gulim')
        mpl.bar(t, y_val, align='center')
        mpl.show()

    def main(self):
        self.fnDict = {1:self.input_info, 2:self.print_info, 3:self.stastic_info, 4:exit}
        while(1):
            print("메인 화면")
            print("     1.입력")
            print("     2.보기")
            print("     3.통계")
            print("     4.종료")
            ans = int(input("번호를 입력하세요:"))
            if ans == 4:
                break
            elif ans > 4:
                print("잘못 입력 하셨습니다\n")
                continue
            self.fnDict[ans]()

        print("프로그램을 종료 합니다.\n")

if __name__ == '__main__':
    pdInfo = pandasInfo()
    pdInfo.main()