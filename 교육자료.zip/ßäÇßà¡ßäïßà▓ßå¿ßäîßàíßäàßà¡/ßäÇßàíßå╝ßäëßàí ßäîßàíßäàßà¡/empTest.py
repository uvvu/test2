class Employee:
    def __init__(self, name, addr):
        self.name= name
        self.addr = addr
    def ShowYourName(self):
        print("name:", self.name)
    def ShowYourAddr(self):
        print("addr:", self.addr)
    
    def empProc(self):  #template method
        self.ShowYourName()
        self.ShowYourAddr()
        self.ShowSalaryInfo()
        
    def GetPay(self):
        pass
    def ShowSalaryInfo(self):
        pass