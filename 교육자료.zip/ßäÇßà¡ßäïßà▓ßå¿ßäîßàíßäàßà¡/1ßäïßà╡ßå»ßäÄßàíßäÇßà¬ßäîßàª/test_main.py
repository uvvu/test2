from test_module import *

def main():
    global infoTuple
    fnDict = {1:input_info, 2:print_info, 3:search_info}
    while(1):
        print("메인 화면")
        print("     1.입력")
        print("     2.출력")
        print("     3.검색")
        print("     4.종료")
        ans = int(input("번호를 입력하세요:"))
        if ans == 4:
            break
        elif ans > 4:
            print("잘못 입력 하셨습니다\n")
            continue
        fnDict[ans]()
    del infoTuple
    print("프로그램을 종료 합니다.\n")


if __name__ == '__main__':
    main()