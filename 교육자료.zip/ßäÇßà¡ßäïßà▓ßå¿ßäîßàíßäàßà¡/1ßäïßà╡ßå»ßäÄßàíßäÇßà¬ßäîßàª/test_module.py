infoTuple = ()

def input_info():
    global infoTuple
    name = str(input("이름:"))
    age = int(input("나이:"))
    addr = str(input("주소:"))
    infoTuple += ({"이름":name, "나이":age, "주소":addr},)

def print_info():
    global infoTuple
    print("================================")
    print("\t이름\t\t나이\t\t주소\t\t")
    print("================================")
    for info in infoTuple:
        print("\t%s\t%d\t%s" % (info['이름'], info['나이'], info['주소']))
        #print("\t{이름}\t{나이}\t{주소}".format(**info))
    print("전체 이름 결과 출력 완료!\n")

def search_info():
    global infoTuple
    name = str(input("검색할 이름을 입력하세요 :"))
    for info in infoTuple:
        if info['이름'] == name:
            print("================================")
            print("\t이름\t\t나이\t\t주소\t\t")
            print("================================")
            print("\t{이름}\t{나이}\t{주소}".format(**info))
    print("검색 결과 출력 완료!\n")