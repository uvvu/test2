addressList = []

def getInput():
#     menu = '''���� �޴�)
#                 1.�Է�
#                 2.���
#                 3.�˻�
#                 4.����
#                 ��ȣ�� �Է��ϼ���:'''
#     return int(input(menu))
    print("���θ޴�","1.�Է�","2.���","3.�˻�","5.����", sep="\n")
    return int(input("��ȣ�� �Է��ϼ���:"))


def inputData():
    while True :
        name = input('�̸�: ')
        age = input('����: ')
        addr = input('�ּ�: ')
#         addressList.append({"name":name,"age":age,"addr":addr})
        addressList.append( (name,age,addr) )
        doLoop = input('��� �Է��Ͻðڽ��ϱ�(y/n) : ')
        if doLoop == 'n' :
            break
        
def printData(addressList):
#     print('----------------------------')
    print('-'*30)
    print('%5s %5s %7s'%("�̸�","����","�ּ�") )
    print('-'*30) 
#     print('----------------------------')
    for item in addressList:
#         print("%(name)10s%(age)10d%(addr)10s"%item )
        print( '%5s %5s %7s' %(item[0], item[1], item[2]))
        
def searchData():
    name = input('�˻��� �̸��� �Է��ϼ���:')
    sData = [item for item in addressList if item[0] == name ]
    printData(sData)
    
#     for item in addressList:
#         if item[0] == name :
#             print('----------------------------')
#             print('    �̸�      ����         �ּ�         ') 
#             print('----------------------------')         
#             print( '%5s %5s %7s' %(item[0], item[1], item[2]))
            
def main():
    mymenu ={1:inputData,2:printData, 3:searchData, 4:exit }
    while True :
        item = getInput()
        if item ==2:
            mymenu[item](addressList)
        else:
            mymenu[item]()
            
#         if item == 1 :
#             inputData()
#         elif item == 2 :
#             printData(addressList)        
#         elif item == 3 :
#             searchData()
#         elif item == 4 :
#             exit()    
            
if __name__ == '__main__':
    main()    