import sqlite3
import sys
from PyQt4.QtGui import *
from PyQt4.QtCore import *
from PyQt4 import uic

class InDlg1:
    def __init__(self):
        self.ui = uic.loadUi('1.ui') # object...
        self.ui.pushButton.clicked.connect(self.btnClick1) # 1번 취소 버튼
        self.ui.pushButton_2.clicked.connect(self.btnClick2)
        self.ui.exec() #modal.. 뜬 상태에서 멈춤. 뒷 메뉴 선택 불가능
        #self.ui.show() #modaless
    
    def btnClick1(self):
        print('click')
        self.ui.close() # 취소메뉴로 종료 시키기
        
    def btnClick2(self):
        print('click2')
        self.data = ()
        mNum = self.ui.lineEdit.text()  # 도서번호
        bDate = self.ui.lineEdit_2.text() # 날짜
        bName = self.ui.lineEdit_3.text() # 도서 이름
        bPub = self.ui.lineEdit_4.text() # 출판사
        bAuth = self.ui.lineEdit_5.text() # 저자
        bKind = self.ui.lineEdit_6.text() # 도서 종류
        #db에 등록하자 - 도서
        self.data = (mNum, bDate, bName, bPub, bAuth, bKind)
        self.makeBookDb()
        self.inputBook()
        
    def inputBook(self):
        try:
            db = sqlite3.connect('final.db')
            cur = db.cursor()
            q="insert into book(mNum, bDate, bName, bPub, bAuth, bKind) \
            values(?, ?, ?, ?, ?, ?)"
            cur.execute(q, self.data)
            db.commit()
            db.close()
            print("insert table success")
        except Exception as err:
            print("err:", err)
        
    def makeBookDb(self):
        try:
            db = sqlite3.connect('final.db')
            cur = db.cursor()
            q="create table book(mNum text, bDate text, bName text,\
             bPub text, bAuth text, bKind text)"
            cur.execute(q)
            db.commit()
            db.close()
            print("create table success")
        except Exception as err:
            print("err:", err)
            
class InDlg2:
    def __init__(self):
        self.ui = uic.loadUi('2.ui') # object...
        self.ui.pushButton.clicked.connect(self.btnClick1) # 1번 취소 버튼
        self.ui.pushButton_2.clicked.connect(self.btnClick2)
        self.ui.radioButton.clicked.connect(self.setSex)
        self.ui.radioButton_2.clicked.connect(self.setSex)
        self.ui.exec() #modal.. 뜬 상태에서 멈춤. 뒷 메뉴 선택 불가능
        #self.ui.show() #modaless
    
    def btnClick1(self):
        print('click')
        self.ui.close() # 취소메뉴로 종료 시키기
        
    def btnClick2(self):
        print('click2')
        #db에 등록하자 - 사람
        self.data = ()
        pID = self.ui.lineEdit.text()  # 회원번호
        pName = self.ui.lineEdit_2.text() # 회원이름
        pPhone = self.ui.lineEdit_3.text() # 회원 전화
        tmpMail = self.ui.lineEdit_4.text() # 이메일 앞자리
        tmpMailAdress = self.ui.lineEdit_6.text() #이메일 뒷자리
        pMail = tmpMail + '@' + tmpMailAdress# 이메일은 4번 + '@' + 6번임 
        pAddr = self.ui.lineEdit_5.text() # 주소
        # pSex = '남자'
        pSex = self.setSex()
        self.data = (pID, pName, pPhone, pMail, pAddr, pSex)
        self.makePersonDb()
        self.inputPerson()
        
    def setSex(self):
        self.s = ""
        if self.ui.radioButton.isChecked():
            self.s = '남자'
        if self.ui.radioButton_2.isChecked():
            self.s = '여자'    
        return self.s
            
    def inputPerson(self):
        try:
            db = sqlite3.connect('final.db')
            cur = db.cursor()
            q="insert into person(pID, pName, pPhone, pMail, pAddr, pSex) \
            values(?, ?, ?, ?, ?, ?)"
            cur.execute(q, self.data)
            db.commit()
            db.close()
            print("insert table success")
        except Exception as err:
            print("err:", err)
            
    def makePersonDb(self):
        try:
            db = sqlite3.connect('final.db')
            cur = db.cursor()
            q="create table person(pID text, pName text, pPhone text,\
             pMail text, pAddr text, pSex text)"
            cur.execute(q)
            db.commit()
            db.close()
            print("create table success")
        except Exception as err:
            print("err:", err)
        
class InDlg3:
    def __init__(self):
        self.ui = uic.loadUi('3.ui') # object...
        self.ui.pushButton.clicked.connect(self.btnClick1) # 1번 취소 버튼
        self.ui.pushButton_2.clicked.connect(self.btnClick2)
        self.ui.comboBox.currentIndexChanged.connect(self.cmbClick)
        self.initWidget()
        self.ui.exec() 
    
    def btnClick1(self):
        print('click')
        # 검색 명령어 날리기
        state = self.cmbClick()
        if state == '관리번호':
            print('관리')
            self.query = "select * from book where mNum='%s'" % (self.ui.lineEdit.text()) #lineEdit값
        elif state == '도서명':
            self.query = "select * from book where bName='%s'" % (self.ui.lineEdit.text()) #lineEdit값
        elif state == '저자':
            self.query = "select * from book where bAuth='%s'" % (self.ui.lineEdit.text())
        self.searchInfo()
        
    def btnClick2(self):
        print('click2')
        self.ui.close()
        # 취소 메뉴로 종료 시키기

    def initWidget(self):
        self.ui.comboBox.addItems(['관리번호','도서명','저자'])
        #self.ui.listWidget.addItem('test')
        
    def cmbClick(self):
        s = self.ui.comboBox.currentText()
        print(s)
        return s
    
    def searchInfo(self):
        try:
            text = []
            db = sqlite3.connect('final.db')
            cur = db.cursor()
            q= self.query
            cur.execute(q)
            s = cur.fetchall()
            for string in s[0]:
                text.append(string)
            self.ui.listWidget.addItems(["관리번호: ", text[0]])
            self.ui.listWidget.addItems(["날짜: ", text[1]])
            self.ui.listWidget.addItems(["도서 이름: ", text[2]])
            self.ui.listWidget.addItems(["출판사: ", text[3]])
            self.ui.listWidget.addItems(["저자: ", text[4]])
            self.ui.listWidget.addItems(["도서 종류: ", text[5]])
            db.commit()
            db.close()
            print("search table success")
        except Exception as err:
            print("err:", err)

class MyDlg: # 0번
    def __init__(self):
        self.ui = uic.loadUi('0.ui') # object...
        self.ui.action.triggered.connect( self.menuClick1)
        self.ui.action_2.triggered.connect( self.menuClick2)
        self.ui.action_3.triggered.connect( self.menuClick3)
        self.initTable()
        self.showTable()
        self.ui.show()
    
    def btnClick(self):
        print('click')
    
    def menuClick1(self):
        dlg = InDlg1()
        print('obj 1 call...')
    
    def menuClick2(self):
        dlg2 = InDlg2()
        print('obj 2 call...')

    def menuClick3(self):
        dlg3 = InDlg3()
        print('obj 3 call...')
        
    def initTable(self):
        self.ui.tableWidget.setColumnCount(6)
        self.ui.tableWidget.setHorizontalHeaderLabels(['관리번호', '날짜', '도서이름', '출판사', '저자', '도서종류'])
    
    def showTable(self):
        try:
            db = sqlite3.connect('final.db') # db가 없으면 만들고 open, 있으면 open만
            cur = db.cursor()
            q="select * from book"
            cur.execute(q)
            self.data = cur.fetchall()
            db.commit()
            db.close()
            print("get all data success")
        except Exception as err:
            print("err:", err)
        self.tableData()
        
    def tableData(self):
        text = []
        n = len(self.data)
        for string in self.data:
            text.append(string)
        self.ui.tableWidget.setRowCount(n)
        for i in range(0, n):
            for j in range(0, len(text[i])):
                self.ui.tableWidget.setItem(i, j, QTableWidgetItem(text[i][j]))
                
        
def main():
    app = QApplication( sys.argv )
    dlg = MyDlg()
    app.exec()

if __name__ == '__main__':
    main()