import sqlite3

class sqlWork:
    def __init__(self):
        self.tmpList = []
    
    def createTable(self):
        try:
            db = sqlite3.connect('exam.db') # db가 없으면 만들고 open, 있으면 open만
            cur = db.cursor()
            q="create table grade(name text, kor int, eng int, math int)"
            cur.execute(q)
            db.commit()
            db.close()
            print("create table success")
        except Exception as err:
            print("err:", err)
    
    def allTable(self):
        try:
            db = sqlite3.connect('exam.db') # db가 없으면 만들고 open, 있으면 open만
            cur = db.cursor()
            q="select * from grade"
            cur.execute(q)
            data = cur.fetchall()
            print("=======================================================")
            print("  이름        국어      영어     수학    총점     평균")
            print("=======================================================")
            for n, k, e, m in data:
                print("%2s%6d%6d%6d%6d%6d" % (n, k, e, m, (k+e+m), ((k+e+m)/3)))
            print("=======================================================") 
            db.commit()
            db.close()
            print("select table success")
        except Exception as err:
            print("err:", err)     
               
    def insertTable(self):
        name = str(input("이름:"))
        kor = int(input("국어:"))
        eng = int(input("영어:"))
        math = int(input("수학:"))
        data = (name, kor, eng, math)
        try:
            db = sqlite3.connect('exam.db')
            cur = db.cursor()
            q="insert into grade(name, kor, eng, math) values(?, ?, ?, ?)"
            cur.execute(q, data)
            db.commit()
            db.close()
            print("insert table success")
        except Exception as err:
            print("err:", err)
    
    def updatetTable(self):
        try:
            db = sqlite3.connect('exam.db') # db가 없으면 만들고 open, 있으면 open만
            cur = db.cursor()
            name = str(input("수정할 이름을 입력하세요:"))
            q = "select * from grade where name='%s'" % (name)
            cur.execute(q)
            data = cur.fetchall()
            for n, k, e, m in data:
                n = n
                k = k
                e = e
                m = m
            tmp = str(input("이름(%s):" % n))
            kor = int(input("국어(%d):" % k))
            eng = int(input("영어(%d):" % e))
            math = int(input("수학(%d):" % m))
            q="update grade set kor=%d, eng=%d, math=%d where name='%s'" % (kor, eng, math, tmp)
            cur.execute(q)
            db.commit()
            db.close()
            print("update table success")
        except Exception as err:
            print("err:", err)

    def deleteTable(self):
        try:
            db = sqlite3.connect('exam.db') # db가 없으면 만들고 open, 있으면 open만
            cur = db.cursor()
            name = str(input("삭제할 이름:"))
            q="delete from grade where name='%s'" % (name)
            cur.execute(q)
            db.commit()
            db.close()
            print("delete table success")
        except Exception as err:
            print("err:", err)
    
    def searchTable(self):
        try:
            db = sqlite3.connect('exam.db') # db가 없으면 만들고 open, 있으면 open만
            cur = db.cursor()
            name = str(input("검색할 이름을 넣으세요:"))
            q = "select * from grade where name='%s'" % (name)
            cur.execute(q)
            data = cur.fetchall()
            print(data)
            db.commit()
            db.close()
            print("search table success")
        except Exception as err:
            print("err:", err)
    
    def sortTable(self):
        try:
            db = sqlite3.connect('exam.db') # db가 없으면 만들고 open, 있으면 open만
            cur = db.cursor()
            yn = str(input("정렬하시겠습니까?(이름순):(y/n)"))
            if yn == 'y':
                q="select * from grade order by name asc"
                cur.execute(q)
                data = cur.fetchall()
                print("=======================================================")
                print("  이름        국어      영어     수학    총점     평균")
                print("=======================================================")
                for n, k, e, m in data:
                    print("%2s%6d%6d%6d%6d%6d" % (n, k, e, m, (k+e+m), ((k+e+m)/3)))
                print("=======================================================")
            else:
                pass
            print("sort table success")
        except Exception as err:
            print("err:", err)
   
    def main(self):
        self.createTable()
        #self.fnDict = {1:self.insertTable, 2:self.updatetTable, 3:self.deleteTable, 4:self.selectTable, 5:exit}
        self.fnDict = {1:self.insertTable, 2:self.allTable,\
                        3:self.deleteTable, 4:self.updatetTable, 5:self.searchTable, 6:self.sortTable, 7:exit} 
        while(1):
            print("메인 화면")
            print("     1.입력")
            print("     2.보기")
            print("     3.삭제")
            print("     4.수정")
            print("     5.검색")
            print("     6.정렬")
            print("     7.종료")
            ans = int(input("번호를 입력하세요:"))
            if ans > 7:
                print("잘못 입력 하셨습니다\n")
                continue
            self.fnDict[ans]()
        print("프로그램을 종료 합니다.\n")
        
if __name__ == '__main__':
    sql = sqlWork()
    sql.main()