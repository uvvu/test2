import xlsxwriter

class Inform:
    def __init__(self):
        self.infoTuple = ()
    
    def input_info(self):
        self.infoTuple
        name = str(input("이름:"))
        korean = int(input("국어:"))
        english = int(input("영어:"))
        self.infoTuple += ({"이름":name, "국어":korean, "영어":english},)
    
    def print_info(self):
        self.infoTuple
        print("================================")
        print("\t이름\t\t국어\t\t영어\t\t")
        print("================================")
        for info in self.infoTuple:
            print("\t%s\t%d\t%s" % (info['이름'], info['국어'], info['영어']))
        print("전체 결과 출력 완료!\n")
    
    def write_excel(self):
        exl = str(input("저장할 파일 이름을 입력하세요:"))
        wb = xlsxwriter.Workbook(exl + ".xlsx")
        ws1 = wb.add_worksheet("mysheet1")
        ws1.write(0, 0, '이름')
        ws1.write(0, 1, '국어')
        ws1.write(0, 2, '영어')
        for idx, info in enumerate(self.infoTuple):
            ws1.write(idx+1, 0, info['이름'])
            ws1.write(idx+1, 1, info['국어'])
            ws1.write(idx+1, 2, info['영어'])
        print("파일명 :", exl, ".xlsx 출력 완료", sep="")
        wb.close()

    def main(self):
        self.infoTuple
        self.fnDict = {1:self.input_info, 2:self.print_info, 3:self.write_excel, 4:exit}
        while(1):
            print("메인 화면")
            print("     1.입력")
            print("     2.출력")
            print("     3.엑셀 저장")
            print("     4.종료")
            ans = int(input("번호를 입력하세요:"))
            if ans == 4:
                break
            elif ans > 4:
                print("잘못 입력 하셨습니다\n")
                continue
            self.fnDict[ans]()
        del self.infoTuple
        print("프로그램을 종료 합니다.\n")


if __name__ == '__main__':
    inf = Inform()
    inf.main()